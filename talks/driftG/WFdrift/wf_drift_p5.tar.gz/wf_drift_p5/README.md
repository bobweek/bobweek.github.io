# drift builds genetic correlations — p5 applet

Self-contained Wright-Fisher drift visualization (no mutation, no recombination):
a population of haploid sequences on the left, the dynamics of every pairwise
locus correlation ρ on the right. Every control is **drawn on the canvas**, so
the applet is a single element with no stray DOM nodes — it scales as one unit
and won't fall apart inside a slide.

## Files
- `index.html` — loads `p5.min.js` + `sketch.js`; responsive canvas
- `sketch.js`  — the whole applet (model + UI), editable
- `p5.min.js`  — bundled p5 1.9.4 (works fully offline)

## Run locally
Just open `index.html`, or serve the folder:
```
python3 -m http.server 8000   # then visit http://localhost:8000
```

## Embed in reveal.js / Quarto
Drop the folder next to your slides and iframe it (this is why DOM controls
break and on-canvas controls don't: reveal scales each slide with a CSS
`transform`, which detaches body-level `<input>` sliders from the canvas; an
iframe of a self-contained page is immune):

```html
<iframe src="wf_drift_p5/index.html"
        style="width:100%; aspect-ratio:1000/620; border:0;"
        loading="lazy"></iframe>
```

In a Quarto `.qmd` reveal slide, put that same `<iframe>` on the slide (raw
HTML is fine), and make sure `wf_drift_p5/` is copied to the output, e.g. in the
YAML header:
```yaml
format:
  revealjs:
    resources:
      - wf_drift_p5
```

## Controls
Sliders: population N, loci L, speed. Buttons: play/pause, step, reset, new
seed. Click a locus column to spotlight every pair involving it.
Keys: `space` play/pause · `s` step · `r` reset · `n` new seed.
