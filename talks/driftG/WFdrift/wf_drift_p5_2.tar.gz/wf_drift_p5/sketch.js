// =====================================================================
//  Drift builds genetic correlations  —  Wright-Fisher, no recombination
//
//  Population of haploid sequences (left) + the dynamics of every pairwise
//  locus correlation (right).  Self-contained p5 sketch: ALL controls are
//  drawn on the canvas (no DOM sliders/buttons), so the whole applet is a
//  single element that scales as one unit when embedded in reveal.js / Quarto
//  slides — nothing can detach from the canvas the way createSlider() does
//  under a slide's CSS transform.
// ---------------------------------------------------------------------
//  Model (haploid Wright-Fisher, N constant, NO mutation, NO recombination):
//    - L biallelic loci, ALL polymorphic; each allele a bright / dark shade of
//      that locus' hue.
//    - start in linkage equilibrium (each locus an independent Bernoulli(1/2)).
//    - each generation the next population is N whole-haplotype copies of
//      random parents.  No recombination => the whole genome rides ONE
//      genealogy, so as lineages coalesce the loci drift into correlation
//      purely from finite-population sampling (LD build-up, fully linked limit).
//
//  Right panel: rho_ij = D_ij / sqrt(p_i(1-p_i) p_j(1-p_j)), D_ij = p_ij-p_i p_j,
//  for every locus pair (L-choose-2 overlapping series).  A line breaks when a
//  locus fixes.  Finite-N floor: E|rho| ~ sqrt(2/pi)/sqrt(N-1) (so for large N
//  the lines hug 0 for a long while before committing).  Transient: the only
//  true endpoint is fixation on a single haplotype.
//
//  Controls (left): population N, loci L, speed; play / step / reset / new seed.
//  Click a locus column to spotlight every pair involving it.
//  Keys: space play/pause · s step · r reset · n new seed.
// =====================================================================

// ---------- internal resolution (CSS scales it to fit the container) ----------
const W = 1000, H = 620;

// ---------- live parameters ----------
let N = 120, L = 10, speed = 12;

// ---------- Rosé Pine Dawn palette (light) ----------
const COL = {
  base:"#faf4ed", surface:"#fffaf3", overlay:"#f2e9e1", hlMed:"#dfdad9",
  muted:"#9893a5", subtle:"#797593", text:"#575279"
};
const ACCENTS = ["#b4637a","#ea9d34","#d7827e","#286983","#56949f","#907aa9"];
let shadeDeep = [], shadeBright = [], pairList = [], pairHue = [];

// ---------- model state ----------
let pop = [], gen = 0, playing = true;
let seedValue = 20250609, rngState = 1;
let genHist = [], rHist = [];
const HIST_MAX = 1400;
const DISPLAY_ROWS = 60;        // legible sample of sequences shown in the panel
let stepAcc = 0, highlightLocus = -1, fold = false, refMode = true, useDprime = true;
const SYM = () => useDprime ? "D\u2032" : "\u03c1";

// ---------- layout ----------
const SX = 24, SW = 198;                       // sidebar
const PX = 246, PW = 320;                       // population
const QX = 608, QW = W - QX - 26;               // correlation plot
const TOP = 96, BOT = H - 40;

// ---------- on-canvas widgets ----------
let sliders = [], buttons = [], dragging = null;

// =====================================================================
function setup(){
  pixelDensity(1);
  createCanvas(W, H);
  textFont('monospace');
  buildPalette();
  buildWidgets();
  initPop();
}

function buildPalette(){
  shadeDeep = []; shadeBright = [];
  for (let k = 0; k < ACCENTS.length; k++){
    const h = color(ACCENTS[k]);
    shadeDeep.push(lerpColor(h, color(COL.text), 0.18));
    shadeBright.push(lerpColor(h, color(255), 0.62));
  }
}
const locusDeep   = l => shadeDeep[l % ACCENTS.length];
const locusBright = l => shadeBright[l % ACCENTS.length];
const locusHue    = l => ACCENTS[l % ACCENTS.length];

function buildWidgets(){
  sliders = [
    { key:'N',     label:'population N', mn:20, mx:240, step:2, get:()=>N,     set:v=>{ if(v!==N){N=v; initPop();} }, y:128 },
    { key:'L',     label:'loci L',       mn:4,  mx:14,  step:1, get:()=>L,     set:v=>{ if(v!==L){L=v; initPop();} }, y:184 },
    { key:'speed', label:'speed',        mn:1,  mx:30,  step:1, get:()=>speed, set:v=>{ speed=v; }, y:240, suffix:' gen/s' }
  ];
  buttons = [
    { label:()=> playing?'pause':'play', x:SX,        y:284, w:SW,            h:30, act:togglePlay },
    { label:()=>'step',                  x:SX,        y:324, w:(SW-12)/3,     h:28, act:()=>{ if(!playing) stepGen(); } },
    { label:()=>'reset',                 x:SX+(SW-12)/3+6, y:324, w:(SW-12)/3, h:28, act:initPop },
    { label:()=>'seed',                  x:SX+2*((SW-12)/3+6), y:324, w:(SW-12)/3, h:28, act:newSeed }
  ];
}

// ---------- seeded RNG (mulberry32) ----------
function srand(s){ rngState = s >>> 0; }
function rnd(){
  rngState |= 0; rngState = (rngState + 0x6D2B79F5) | 0;
  let t = Math.imul(rngState ^ (rngState >>> 15), 1 | rngState);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const ri = n => Math.floor(rnd() * n);

// ---------- model ----------
function buildPairs(){
  pairList = []; pairHue = [];
  for (let i = 0; i < L; i++)
    for (let j = i + 1; j < L; j++){ pairList.push([i, j]); pairHue.push(locusHue(i)); }
}
function initPop(){
  srand(seedValue);
  buildPairs();
  pop = [];
  for (let i = 0; i < N; i++){
    const row = new Uint8Array(L);
    for (let l = 0; l < L; l++) row[l] = rnd() < 0.5 ? 1 : 0;
    pop.push(row);
  }
  gen = 0; stepAcc = 0; highlightLocus = -1;
  pop.sort((a, b) => { for (let l = 0; l < L; l++){ if (a[l] !== b[l]) return a[l] - b[l]; } return 0; });
  genHist = []; rHist = pairList.map(() => []);
  record();
}
function stepGen(){
  const next = [];
  for (let i = 0; i < N; i++) next.push(pop[ri(N)].slice());
  pop = next;
  pop.sort((a, b) => { for (let l = 0; l < L; l++){ if (a[l] !== b[l]) return a[l] - b[l]; } return 0; });
  gen++; record();
}
function corr(i, j){
  let cA = 0, cB = 0, cAB = 0;
  for (let k = 0; k < N; k++){ const a = pop[k][i], b = pop[k][j]; cA += a; cB += b; cAB += a & b; }
  const pa = cA / N, pb = cB / N;
  if (pa === 0 || pa === 1 || pb === 0 || pb === 1) return null;
  const D = cAB / N - pa * pb;
  return D / Math.sqrt(pa * (1 - pa) * pb * (1 - pb));
}
function dprime(i, j){
  // Lewontin's D' = D / D_max : reaches +/-1 when one gamete type is absent
  // (complete LD), independent of allele frequency.
  let cA = 0, cB = 0, cAB = 0;
  for (let k = 0; k < N; k++){ const a = pop[k][i], b = pop[k][j]; cA += a; cB += b; cAB += a & b; }
  const p = cA / N, q = cB / N;
  if (p === 0 || p === 1 || q === 0 || q === 1) return null;
  const D = cAB / N - p * q;
  const Dmax = D >= 0 ? Math.min(p * (1 - q), (1 - p) * q)
                      : Math.min(p * q, (1 - p) * (1 - q));
  return Dmax === 0 ? null : D / Dmax;
}
function pairStat(i, j){ return useDprime ? dprime(i, j) : corr(i, j); }
function record(){
  genHist.push(gen);
  for (let k = 0; k < pairList.length; k++)
    rHist[k].push(pairStat(pairList[k][0], pairList[k][1]));
  if (genHist.length > HIST_MAX){
    genHist = genHist.filter((_, i) => i % 2 === 0);
    rHist = rHist.map(a => a.filter((_, i) => i % 2 === 0));
  }
}
function nHaplotypes(){
  const s = new Set();
  for (let k = 0; k < N; k++) s.add(pop[k].join(''));
  return s.size;
}

// =====================================================================
function draw(){
  background(COL.base);
  if (playing){
    stepAcc += (deltaTime / 1000) * speed;
    let budget = 0;
    // advance at most ONE generation per drawn frame, so playback never skips a
    // generation (no manufactured jumps); speed sets how often we step
    while (stepAcc >= 1 && budget < 1){ stepGen(); stepAcc -= 1; budget++; }
    if (stepAcc > 1) stepAcc = 1;
  }
  drawSidebar();
  drawHeader();
  drawPopulation();
  drawCorrelations();
}

// ---------- header ----------
function drawHeader(){
  noStroke(); textAlign(LEFT, BASELINE);
  fill(COL.text); textSize(19); textStyle(BOLD);
  text("drift builds genetic correlations", PX, 40);
  textStyle(NORMAL); fill(COL.subtle); textSize(11);
  text("Wright-Fisher resampling of whole haplotypes · no mutation, no recombination", PX, 58);

  fill(COL.text); textSize(12); textStyle(BOLD);
  text("POPULATION", PX, TOP - 10);
  textStyle(NORMAL); fill(COL.subtle); textSize(11);
  textAlign(RIGHT, BASELINE);
  const shown = Math.min(N, DISPLAY_ROWS);
  text((shown < N ? shown + " of " + N + " seqs · " : "") + "gen " + gen, PX + PW, TOP - 10);

  fill(COL.text); textSize(12); textStyle(BOLD); textAlign(LEFT, BASELINE);
  const baseHdr = useDprime ? "LINKAGE D\u2032" : "CORRELATIONS";
  text(refMode ? (SYM() + " vs locus 1") : baseHdr, QX, TOP - 10);
  textStyle(NORMAL); fill(COL.subtle); textSize(11);
  if (!refMode) text("one line per locus pair", QX + 102, TOP - 10);
}

// ---------- population ----------
function drawPopulation(){
  const h = BOT - TOP, cellW = PW / L;
  noStroke(); fill(COL.surface); rect(PX, TOP, PW, h, 4);
  // show a legible sample of whole sequences (full population drives the
  // correlations; here rows are resolvable even when N is large)
  const Nfull = pop.length, R = Math.min(Nfull, DISPLAY_ROWS);
  const rowH = h / R, GAP = rowH > 4 ? 1.4 : 0;   // tiny gap BETWEEN sequences
  noStroke();
  for (let r = 0; r < R; r++){
    const src = (Nfull > R) ? Math.round(r * (Nfull - 1) / (R - 1)) : r;
    const row = pop[src], by = TOP + r * rowH;
    for (let l = 0; l < L; l++){
      fill(row[l] ? locusBright(l) : locusDeep(l));
      rect(PX + l * cellW, by, cellW + 0.6, Math.max(1, rowH - GAP));  // columns flush
    }
  }
  if (highlightLocus >= 0 && highlightLocus < L){
    noFill(); stroke(COL.text); strokeWeight(1.6);
    rect(PX + highlightLocus * cellW, TOP, cellW, h);
    const cx = PX + (highlightLocus + 0.5) * cellW;
    line(cx - cellW * 0.18, TOP - 5, cx, TOP - 11);
    line(cx, TOP - 11, cx + cellW * 0.18, TOP - 5);
  }
  noStroke();
}

// ---------- correlation dynamics ----------
function drawCorrelations(){
  const h = BOT - TOP, x0 = QX, y0 = TOP, w = QW, yMid = y0 + h / 2;
  noStroke(); fill(COL.surface); rect(x0, y0, w, h, 4);

  stroke(COL.hlMed); strokeWeight(1); drawingContext.setLineDash([2, 4]);
  line(x0, y0, x0 + w, y0);                                   // |rho| or +rho = 1
  if (!fold) line(x0, y0 + h, x0 + w, y0 + h);                // -1 only when signed
  drawingContext.setLineDash([]);
  stroke(COL.muted); line(x0, fold ? y0 + h : yMid, x0 + w, fold ? y0 + h : yMid);
  noStroke(); fill(COL.subtle); textSize(9.5); textAlign(RIGHT, CENTER);
  if (fold){
    text("1", x0 - 4, y0); text("0.5", x0 - 4, yMid); text("0", x0 - 4, y0 + h);
  } else {
    text("+1", x0 - 4, y0); text("0", x0 - 4, yMid); text("\u22121", x0 - 4, y0 + h);
  }
  textAlign(CENTER, TOP); text("generation", x0 + w / 2, y0 + h + 8);
  push(); translate(x0 - 30, yMid); rotate(-HALF_PI);
  textAlign(CENTER, BOTTOM); fill(COL.subtle);
  text((refMode ? (SYM() + " with locus 1")
                : ((useDprime ? "Lewontin's D\u2032  " : "genetic correlation  ") + (fold ? "|" + SYM() + "|" : SYM()))), 0, 0); pop();

  const n = genHist.length;
  if (n >= 2){
    const gmax = Math.max(1, genHist[n - 1]);
    const xx = g => x0 + (g / gmax) * w;
    const yy = v => fold ? (y0 + h - Math.abs(v) * h) : (yMid - v * (h / 2));
    for (let k = 0; k < pairList.length; k++){
      if (refMode && pairList[k][0] !== 0) continue;   // only rho vs locus 1
      const involved = highlightLocus >= 0 &&
                       (pairList[k][0] === highlightLocus || pairList[k][1] === highlightLocus);
      const c = color(refMode ? locusHue(pairList[k][1]) : pairHue[k]);
      if (highlightLocus >= 0 && !involved){ stroke(red(c), green(c), blue(c), 26); strokeWeight(1); }
      else { stroke(red(c), green(c), blue(c), highlightLocus >= 0 ? 235 : (refMode ? 200 : 130)); strokeWeight(involved ? 2.0 : (refMode ? 1.7 : 1.3)); }
      noFill();
      const arr = rHist[k]; let open = false;
      for (let t = 0; t < n; t++){
        const v = arr[t];
        if (v === null || v === undefined){ if (open){ endShape(); open = false; } continue; }
        if (!open){ beginShape(); open = true; }
        vertex(xx(genHist[t]), yy(v));
      }
      if (open) endShape();
    }
  }

  // readouts
  let mAbs = 0, cnt = 0, committed = 0;
  for (let k = 0; k < pairList.length; k++){
    if (refMode && pairList[k][0] !== 0) continue;
    const v = rHist[k][rHist[k].length - 1];
    if (v !== null && v !== undefined){ mAbs += Math.abs(v); cnt++; if (Math.abs(v) >= 0.9) committed++; }
  }
  mAbs = cnt ? mAbs / cnt : 0;
  const nh = nHaplotypes();
  noStroke(); textAlign(LEFT, BASELINE); fill(COL.text); textSize(11);
  text(nh === 1 ? "fixed — one haplotype" : "mean |" + SYM() + "| = " + nf(mAbs, 1, 2), x0, y0 - 26);
  textAlign(RIGHT, BASELINE); fill(COL.subtle); textSize(10.5);
  text(nh === 1 ? "press r / n" : committed + " pairs at |" + SYM() + "| ≥ 0.9", x0 + w, y0 - 26);
  textAlign(RIGHT, BASELINE); fill(COL.muted); textSize(10);
  text(nh + " haplotype" + (nh === 1 ? "" : "s"), x0 + w - 6, y0 + h - 6);
}

// ---------- sidebar + on-canvas widgets ----------
function drawSidebar(){
  noStroke(); fill(COL.surface); rect(SX - 8, 18, SW + 16, H - 36, 8);
  stroke(COL.hlMed); strokeWeight(1); noFill(); rect(SX - 8, 18, SW + 16, H - 36, 8);

  noStroke(); fill(COL.text); textSize(13); textStyle(BOLD); textAlign(LEFT, BASELINE);
  text("controls", SX, 44); textStyle(NORMAL);

  for (const s of sliders) drawSlider(s);
  for (const b of buttons) drawButton(b);

  // hint
  fill(COL.subtle); textSize(10); textAlign(LEFT, TOP);
  text("space play · s step\nr reset · n new seed\nf fold · m vs locus 1\nd  D\u2032 / \u03c1\nclick a locus to spotlight", SX, 372);

  // tiny legend: bright = allele 1, dark = allele 0
  const ly = 470;
  fill(COL.text); textSize(10.5); textStyle(BOLD); text("allele shades", SX, ly);
  textStyle(NORMAL);
  noStroke();
  fill(locusBright(3)); rect(SX, ly + 10, 16, 12, 2);
  fill(COL.subtle); textSize(10); textAlign(LEFT, CENTER); text("allele 1 (bright)", SX + 24, ly + 16);
  fill(locusDeep(3)); rect(SX, ly + 28, 16, 12, 2);
  fill(COL.subtle); text("allele 0 (deep)", SX + 24, ly + 34);
}

function sliderFrac(s){ return (s.get() - s.mn) / (s.mx - s.mn); }
function drawSlider(s){
  const x = SX, y = s.y, w = SW;
  noStroke(); fill(COL.text); textSize(11); textAlign(LEFT, BASELINE);
  text(s.label + " = " + s.get() + (s.suffix || ''), x, y - 10);
  stroke(COL.hlMed); strokeWeight(3); line(x, y, x + w, y);
  const hx = x + sliderFrac(s) * w;
  stroke(color(ACCENTS[3])); strokeWeight(3); line(x, y, hx, y);
  noStroke(); fill(COL.surface); stroke(COL.subtle); strokeWeight(1.5);
  circle(hx, y, 13); noStroke();
}
function drawButton(b){
  const hover = inRect(mouseX, mouseY, b.x, b.y, b.w, b.h);
  noStroke(); fill(hover ? COL.overlay : COL.base);
  stroke(hover ? COL.subtle : COL.hlMed); strokeWeight(1);
  rect(b.x, b.y, b.w, b.h, 6);
  noStroke(); fill(COL.text); textSize(12); textAlign(CENTER, CENTER);
  text(b.label(), b.x + b.w / 2, b.y + b.h / 2 + 1);
}
function inRect(mx, my, x, y, w, h){ return mx >= x && mx <= x + w && my >= y && my <= y + h; }

// ---------- interaction ----------
function setSliderFromMouse(s){
  const t = constrain((mouseX - s.x) / SW, 0, 1);
  let v = s.mn + Math.round((t * (s.mx - s.mn)) / s.step) * s.step;
  v = constrain(v, s.mn, s.mx);
  s.set(v);
}
function mousePressed(){
  for (const s of sliders){
    if (mouseX >= s.x - 8 && mouseX <= s.x + SW + 8 && Math.abs(mouseY - s.y) <= 12){
      dragging = s; setSliderFromMouse(s); return;
    }
  }
  for (const b of buttons){ if (inRect(mouseX, mouseY, b.x, b.y, b.w, b.h)){ b.act(); return; } }
  if (inRect(mouseX, mouseY, PX, TOP, PW, BOT - TOP)){
    const loc = Math.floor((mouseX - PX) / (PW / L));
    highlightLocus = (loc === highlightLocus) ? -1 : loc;
  }
}
function mouseDragged(){ if (dragging) setSliderFromMouse(dragging); }
function mouseReleased(){ dragging = null; }

function togglePlay(){ playing = !playing; }
function newSeed(){ seedValue = (Math.random() * 4294967296) >>> 0; initPop(); }

function keyPressed(){
  if (key === ' ') { togglePlay(); return false; }
  if (key === 's' || key === 'S') { if (!playing) stepGen(); }
  if (key === 'r' || key === 'R') initPop();
  if (key === 'n' || key === 'N') newSeed();
  if (key === 'f' || key === 'F') fold = !fold;
  if (key === 'm' || key === 'M') refMode = !refMode;
  if (key === 'd' || key === 'D') { useDprime = !useDprime; initPop(); }
}
